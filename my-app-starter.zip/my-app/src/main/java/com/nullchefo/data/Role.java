package com.nullchefo.data;

public enum Role {
    USER, ADMIN;
}
